#  Program
def main():
    print("This is  program in Python")

if __name__ == "__main__":
    main()
