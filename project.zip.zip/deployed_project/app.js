// calculator - JavaScript Program

function add(a,b) {
    return a+b;
}

function subtract(a,b) {
    return a-b;
}

console.log("Addition:", add(10,5));
console.log("Subtraction:", subtract(10,5));
