# calculate - Python Program

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def main():
    print("Addition:", add(10,5))
    print("Subtraction:", subtract(10,5))

if __name__ == "__main__":
    main()
