# calculator program in Python
print("Hello from calculator")