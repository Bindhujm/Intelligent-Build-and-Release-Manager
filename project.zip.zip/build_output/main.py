def add(x, y):
    return x + y

def sub(x, y):
    return x - y

def mul(x, y):
    return x * y

def div(x, y):
    if y == 0:
        return "Error: Division by zero"
    else:
        return x / y

def mod(x, y):
    if y == 0:
        return "Error: Division by zero"
    else:
        return x % y

def power(x, y):
    return x ** y

def factorial(x):
    if x == 0:
        return 1
    else:
        return x * factorial(x - 1)

def sqrt(x):
    if x < 0:
        return "Error: Square root of negative number"
    else:
        return x ** 0.5

def main():
    print("Simple Calculator")
    print("-----------------")
    while True:
        print("\n1. Addition")
        print("2. Subtraction")
        print("3. Multiplication")
        print("4. Division")
        print("5. Modulus")
        print("6. Power")
        print("7. Factorial")
        print("8. Square Root")
        print("9. Exit")
        
        choice = input("Choose an operation (1-9): ")

        if choice == "9":
            print("Exiting the program. Goodbye!")
            break

        elif choice not in ["1", "2", "3", "4", "5", "6", "7", "8"]:
            print("Invalid choice. Please enter a number between 1 and 9.")

        else:
            num1 = float(input("Enter the first number: "))
            num2 = float(input("Enter the second number: "))

            if choice == "1":
                print(f"{num1} + {num2} = {add(num1, num2)}")

            elif choice == "2":
                print(f"{num1} - {num2} = {sub(num1, num2)}")

            elif choice == "3":
                print(f"{num1} * {num2} = {mul(num1, num2)}")

            elif choice == "4":
                print(f"{num1} / {num2} = {div(num1, num2)}")

            elif choice == "5":
                print(f"{num1} % {num2} = {mod(num1, num2)}")

            elif choice == "6":
                print(f"{num1} ^ {num2} = {power(num1, num2)}")

            elif choice == "7":
                print(f"Factorial({num1}) = {factorial(num1)}")

            elif choice == "8":
                print(f"Square Root of {num1} = {sqrt(num1)}")

if __name__ == "__main__":
    main()