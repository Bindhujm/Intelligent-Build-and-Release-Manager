def test_project():
    print("Testing project...")
