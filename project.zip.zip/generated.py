# Auto Generated calculator Program

print("This is a generated program for calculator")
